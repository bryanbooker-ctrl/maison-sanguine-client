# Translation conventions (keep consistent across chunks)
Files: srcNN.txt (source, @index), outNNa.txt (es pt it de), outNNb.txt (ru ja ko zh). Format: "@i" then "xx text" lines; "@i =" means same as English for all; "xx =" same as English for that language.
Account ns (@0-152) is translated by position in React; other ns share one value per key.
Split headings: es/pt/it mirror the FR piece order (translate the FR value); de/ru/ja/ko/zh mirror the EN piece order.
Register: es usted (neutral Spain+Mexico) | pt Brazilian, você | it formal Lei, lowercase possessives | de Sie | ru Вы | ja です・ます + 敬語 | ko 하십시오체 | zh traditional, 您.
Kept in Latin everywhere: Maison Sanguine, Haute Nuit, Night Collection, Winter Edition (and other Edition names), EXTEND, Absolute Mastery, House of Jubilation, MS Archives, Portfolio, The Night Keepers, Studio, savoir-faire (es/pt/it/de), RD#.
Guest Relations: kept in es/pt/it/de (de: Guest-Relations-Team) | ru служба Guest Relations | ja ゲストリレーションズ | ko 게스트 릴레이션 팀 | zh 賓客關係團隊
the Maison: la Maison | a Maison | la Maison | die Maison | Дом | メゾン | 메종 | Maison
Season: Temporada | Temporada | Stagione | Saison | Сезон | シーズン | 시즌 | 季
night: noche | noite | notte | Nacht | ночь | 夜 | 밤 | 夜
masterclass: masterclass(es) f | masterclass(es) f | masterclass f inv. | Masterclass(es) | мастер-класс | マスタークラス | 마스터클래스 | 大師班
MS Account: Cuenta MS | Conta MS | Account MS | MS Account | аккаунт MS | MSアカウント | MS 계정 | MS 帳戶
My MS: Mi MS | Meu MS | Il mio MS | Mein MS | Мой MS | マイMS | 마이 MS | 我的 MS
invitation: invitación | convite | invito | Einladung | приглашение | 招待状 | 초대장 | 邀請函
selection committee: comité de selección | comitê de seleção | comitato di selezione | Auswahlkomitee | отборочный комитет | 選考委員会 | 선정 위원회 | 遴選委員會
booking/reservation: reserva | reserva | prenotazione | Buchung/Reservierung | бронирование | ご予約 | 예약 | 預訂
request: solicitud | pedido | richiesta | Anfrage | заявка | リクエスト/お申し込み | 신청 | 申請
production: producción | produção | produzione | Produktion | постановка | プロダクション | 프로덕션 | 製作
sound architecture: arquitectura sonora | arquitetura sonora | architettura sonora | Klangarchitektur | звуковая архитектура | サウンドアーキテクチャ | 사운드 아키텍처 | 聲音建築
scenography: escenografía | cenografia | scenografia | Szenografie | сценография | セノグラフィー | 시노그래피 | 場景設計
No em dashes anywhere. Never "public/audience" words: use guests (invitados / convidados / ospiti / Gäste / гости / ゲスト / 게스트 / 賓客).
