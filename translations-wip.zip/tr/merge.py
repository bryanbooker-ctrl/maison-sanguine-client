import json,re,glob,sys
items=json.load(open('items.json'))
L=['es','pt','it','de','ru','ja','ko','zh']
out={l:{} for l in L};errs=[]
for f in sorted(glob.glob('out*.txt')):
  cur=None
  for ln,line in enumerate(open(f).read().split('\n'),1):
    if not line.strip():continue
    if line.startswith('@'):
      m=re.match(r'@(\d+)( =)?$',line)
      if not m:errs.append(f'{f}:{ln} bad header {line!r}');continue
      cur=int(m.group(1))
      if m.group(2):
        for l in ('es','pt','it','de') if f[-5]=='a' else ('ru','ja','ko','zh'):out[l][cur]=items[cur][2]
      continue
    m=re.match(r'(es|pt|it|de|ru|ja|ko|zh) (.*)$',line)
    if not m or cur is None:errs.append(f'{f}:{ln} bad line {line[:50]!r}');continue
    l,t=m.groups()
    if (l in ('es','pt','it','de'))!=(f[-5]=='a'):errs.append(f'{f}:{ln} lang in wrong file')
    if cur in out[l]:errs.append(f'{f}:{ln} duplicate @{cur} {l}')
    out[l][cur]=items[cur][2] if t=='=' else t
def sig(s):return sorted(re.findall(r'\{\w+\}|<[^>]+>|\]\([^)]*\)',s))
done=set().union(*[set(out[l]) for l in L])
for i in sorted(done):
  src=items[i][2]
  for l in L:
    if i not in out[l]:errs.append(f'@{i} missing {l}');continue
    t=out[l][i]
    if '—' in t or '–' in t and '–' not in src:errs.append(f'@{i} {l} dash')
    a,b=sig(src),sig(t)
    if a!=b:errs.append(f'@{i} {l} sig {a} vs {b}')
    if re.search(r'&(?!amp;|gt;|lt;)',t) and not re.search(r'&(?!amp;|gt;|lt;)',src):errs.append(f'@{i} {l} raw amp')
    if src.startswith('. ')!=(t[:1] in '.。') : errs.append(f'@{i} {l} leading dot')
    if src.endswith(' *')!=t.endswith(' *'):errs.append(f'@{i} {l} star')
    if l in('ja','zh') and re.search(r'[가-힣]',t):errs.append(f'@{i} {l} hangul')
    if l=='ko' and re.search(r'[぀-ヿ]',t):errs.append(f'@{i} ko kana')
    if l=='zh' and re.search(r'[぀-ヿ]',t):errs.append(f'@{i} zh kana')
    if l=='ru' and re.search(r'[A-Za-z]{4,}',t) and not re.search(r'[A-Za-z]{4,}',src):pass
    if re.search(r'  |\s$|^\s',t):errs.append(f'@{i} {l} spaces')
print('translated',len(done),'/',len(items),'errors',len(errs))
for e in errs[:60]:print(' ',e)
json.dump(out,open('merged.json','w'),ensure_ascii=False)
