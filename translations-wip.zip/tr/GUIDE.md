# Translation guide (Maison Sanguine) - keep consistent across batches

Pipeline: src/NN.txt (EN+FR) -> out/NN.txt written by hand -> assemble.py -> messages/<lang>.json
Out format, per entry:
@key
es|… pt|… de|… it|… ja|… ko|… zh|… ru|…   (one per line, `zh` = zh-hant)

Context keys: EN shows "prev || text" (translate only `text`) or "text >> next" (translate only `text`).
Heading pieces are separate lines of one title: pieces may be reordered so the full title reads naturally.

Never translate: Maison Sanguine, MS Archives, MS Account, MS House, MS Beyond, Haute Nuit, EXTEND / Extend™,
Shimmering Air, Tissage (+Architectural/Embarqué/Environnemental), House of Jubilation, Initiative Maison Sanguine,
Winter Edition, Spring Edition, Rite of Summer, Fall Edition, New Year's Eve, MSNYE, Newcomer, Nightkeeper, Keepers,
Absolute Mastery (RD#3) as framework name, RD#, Masters of Sound, Born in Paris (hero), Season 2027 by Maison Sanguine,
Studio, Savoir-Faire (keep "savoir-faire"), Masterclass (ja マスタークラス, ko 마스터클래스, zh 大師班, ru мастер-класс).

Terms: Season(cap.) es Temporada | pt Temporada | de Saison | it Stagione | ja シーズン | ko 시즌 | zh 季度→use「Season」? NO: zh 樂季→ use 「季」 e.g. 2027 季 ; ru Сезон
night: noche | noite | Nacht | notte | 夜 | 밤 | 夜 | ночь.  Maison: keep "Maison" (ja メゾン, ko 메종, zh 品牌/Maison keep "Maison", ru Дом→ keep «Maison»).
Night Collection menu: es Todas las noches | pt Todas as noites | de Alle Nächte | it Tutte le notti | ja すべての夜 | ko 모든 밤 | zh 所有夜晚 | ru Все ночи
Discover more: Descubrir | Descobrir | Entdecken | Scopri | 詳しく見る | 자세히 보기 | 探索更多 | Узнать больше
Read more: Leer más | Ler mais | Weiterlesen | Leggi di più | 続きを読む | 더 읽기 | 閱讀更多 | Читать далее
admission: admisión | admissão | Zulassung | ammissione | ご入場 | 입장 | 入場 | допуск
booking: reserva | reserva | Buchung | prenotazione | ご予約 | 예약 | 預訂 | бронирование

Rules: never "public/audience" words; no em dashes; formal address (usted, você, Sie, Lei/voi-impersonal, です・ます敬語, 합쇼체, 您, Вы).
Typography: es ¿¡ «»→ use “ ”; de „“; it «»; ja/zh 「」 full-width punctuation; ru «»; apostrophe ’.
Keep entities (&amp;, &gt;), {placeholders}, URLs, markdown links, numbers, leading/trailing spaces and punctuation shape.
pt = Brazilian Portuguese. es = neutral (Spain + Mexico). zh = Traditional (HK/MO/TW).

## Split-title decisions already taken (keep matching halves consistent)
- "Our 2027" plain -> es Nuestra Temporada | pt Nossa Temporada | de Unsere Saison | it La nostra Stagione | ja 私たちの | ko 우리의 | zh 我們的 | ru Наш Сезон   (context "Season" after it = 2027 / 2027年シーズン / 2027 시즌 / 2027 季)
- "Innovative >> Atmospheres" first piece -> es Una búsqueda constante | pt Uma busca constante | de Die stete Suche | it Una ricerca costante | ja 革新的なアトモスフィアへの | ko 혁신적인 분위기를 향한 | zh 對創新氛圍的 | ru Постоянный поиск
- "Absolute" plain (hero) -> es Maestría | pt Maestria | de Absolute | it Maestria | ja 絶対的な | ko 절대적 | zh 極致 | ru Абсолютное
- "Spatial" plain -> es Diseño | pt Design | de Raum- | it Design | ja 空間 | ko 공간 | zh 空間 | ru Пространственный
- "Change" plain (location window title) -> es Cambiar | pt Alterar | de Ändern: | it Cambia | ja 変更： | ko 변경: | zh 變更 | ru Изменить
- Terms: property=propiedad/propriedade/Anwesen/proprietà/プロパティ/프로퍼티/場域/владение ; production=producción/produção/Produktion/produzione/プロダクション/프로덕션/製作/постановка ; experience(ru)=впечатление ; scenography=セノグラフィー/세노그래피/場景設計 ; sound architecture=音響建築/사운드 아키텍처/聲音建築/звуковая архитектура ; Guest Relations=Relaciones con los Invitados/Relacionamento com Convidados/Guest-Relations-Team/team Guest Relations/ゲストリレーションズ/게스트 릴레이션/賓客關係/команда по работе с гостями ; MS Account=Cuenta MS/Conta MS/MS-Konto/Account MS/MSアカウント/MS 계정/MS 帳戶/аккаунт MS ; cities: Aspen アスペン 아스펜 阿斯本 Аспен; NY ニューヨーク 뉴욕 紐約 Нью-Йорк (es Nueva York, pt Nova York); Saint-Tropez サントロペ 생트로페 聖特羅佩 Сен-Тропе; Paris パリ 파리 巴黎 Париж (es París, it Parigi); Saint-Barth サン・バルテルミー 생바르텔레미 聖巴瑟米 Сен-Бартелеми
- Progress: out/00..21 done (all legal done). User chose option 3 (finish all 8 langs incl. legal), audit in a later session. (09 = all context keys; de Spatial=Räumliches + ctx Design=Design)

## STATE SAVED 2026-11-12 18:20 — resume here
- Done: out/00..21 (1129/1586 texts, 8 langs). Remaining: src/22..32 (22 was read but NOT written).
- To resume: read src/22.txt, write out/22.txt ... out/32.txt, then `python3 assemble.py --write`,
  then add the 8 imports in lib/messages.ts + LOCALES/TRANSLATED in lib/locales.ts, build, review headings per language, apply NOTES.md todos.
- Languages are NOT activated on the site yet (lib/messages.ts only imports en+fr).
