import json,re
from babel import Locale
en=json.load(open('/home/claude/build/messages/en.json'));fr=json.load(open('/home/claude/build/messages/fr.json'))
L=Locale('en');terr={v:k for k,v in L.territories.items() if len(k)==2}
terr.update({'Hong Kong':'HK','Macao':'MO','Palestine':'PS','Congo':'CG','Myanmar':'MM','Czech Republic':'CZ','Turkey':'TR','Ivory Coast':'CI','Cape Verde':'CV','Swaziland':'SZ','Democratic Republic of the Congo':'CD','Republic of the Congo':'CG','Micronesia':'FM','Bosnia and Herzegovina':'BA','Antigua and Barbuda':'AG','Saint Kitts and Nevis':'KN','Saint Vincent and the Grenadines':'VC','Trinidad and Tobago':'TT','Sao Tome and Principe':'ST','Vatican City':'VA','East Timor':'TL','United States':'US','United Kingdom':'GB','Russia':'RU','South Korea':'KR','North Korea':'KP','Brunei':'BN'})
tu={k.upper():v for k,v in terr.items()}
U={};order=[]
for ns,d in en.items():
  for k,v in d.items():
    if k not in U:U[k]={'en':v,'fr':fr[ns].get(k,''),'ns':ns};order.append(k)
auto={};todo=[]
for k in order:
  v=U[k]['en'];ns=U[k]['ns']
  if ns in('subscription','press','locations','location') and v in terr: auto[k]=('T',terr[v]);continue
  if ns=='press' and v in tu and v==v.upper(): auto[k]=('TU',tu[v]);continue
  if not re.search('[A-Za-z]{2}',v) or v in('" novalidate',"':'&gt;','") or re.fullmatch(r'[A-Z]{2}( [A-Z]{2}){20,}',v) or '@maisonsanguine' in v and ' ' not in v or re.fullmatch(r'NAME_\d',v): auto[k]=('C',v);continue
  todo.append(k)
json.dump(auto,open('/home/claude/tr/auto.json','w'));json.dump({k:U[k] for k in todo},open('/home/claude/tr/todo.json','w'),ensure_ascii=False)
# batches ~3200 chars EN
b=[];cur=[];n=0
for k in todo:
  l=len(U[k]['en'])
  if cur and n+l>3200:b.append(cur);cur=[];n=0
  cur.append(k);n+=l
if cur:b.append(cur)
for i,ks in enumerate(b):
  with open(f'/home/claude/tr/src/{i:02d}.txt','w') as f:
    for k in ks:
      u=U[k];f.write(f"@{k} [{u['ns']}]\nEN: {u['en']!s}\nFR: {u['fr']!s}\n".replace('\r',''))
print(len(auto),len(todo),len(b),sum('\n' in U[k]['en'] for k in todo))
