import json,re,glob,sys
from babel import Locale
LANGS=['es','pt','de','it','ja','ko','zh','ru'];FILE={'zh':'zh-hant'};BAB={'zh':'zh_Hant','pt':'pt_BR'}
B='/home/claude/build/messages/'
en=json.load(open(B+'en.json'));todo=json.load(open('todo.json'));auto=json.load(open('auto.json'))
T={l:{} for l in LANGS};TA={l:{} for l in LANGS};errs=[]
for f in sorted(glob.glob('out/*.txt')):
  k=None
  for n,line in enumerate(open(f).read().split('\n'),1):
    if not line.strip():continue
    if line.startswith('@'):k=line[1:].strip();continue
    m=re.match(r'^(es|pt|de|it|ja|ko|zh|ru)\|(.*)$',line)
    if not m or k is None:errs.append(f'{f}:{n} bad line {line[:40]!r}');continue
    if k.endswith('#account'):TA[m.group(1)][k[:-8]]=m.group(2)
    else:T[m.group(1)][k]=m.group(2)
def chk(l,k,src,v):
  if not v.strip():return 'empty'
  for pat in (r'\{[a-zA-Z_]+\}',r'&[a-z]+;',r'https?://[^\s)\]]+',r'\d+'):
    a=sorted(re.findall(pat,src));b=sorted(re.findall(pat,v))
    if pat==r'\d+':
      a=[x for x in a if len(x)>1];b2=''.join(re.findall(r'\d',v))
      miss=[x for x in a if x not in v and x not in b2]
      if miss and not(l in('ja','ko','zh')and all(len(x)<=2 for x in miss)):return f'numbers {miss}'
    elif a!=b:return f'{pat}: {a} vs {b}'
  if '—' in v or '–' in v:return 'dash'
  if src[:1]==' ' and v[:1]!=' ':return 'lead space'
  if src[-1:]==' ' and v[-1:]!=' ':return 'trail space'
  if l in('ja','ko','zh','ru') and len(src)>60 and not re.search(r'[^\x00-ɏ]',v):return 'not translated?'
  if len(src)>80 and not((0.12 if l in('ja','ko','zh') else 0.4)<len(v)/len(src)<2.2):return f'length ratio {len(v)/len(src):.2f}'
  if re.search(r'  ',v.strip()):return 'double space'
  if l=='zh' and re.search('[们这为国时见说发]',v):return 'simplified char'
  return None
done=0
for l in LANGS:
  miss=[k for k in todo if k not in T[l]]
  done=len(todo)-len(miss)
  for k,v in T[l].items():
    if k not in todo:errs.append(f'{l} unknown key {k}');continue
    e=chk(l,k,todo[k]['en'],v)
    if e:errs.append(f'{l} {k} {e} | {v[:60]}')
  if '--write' in sys.argv:
    loc=Locale.parse(BAB.get(l,l));out={}
    for ns,d in en.items():
      o={}
      for k,src in d.items():
        if ns=='account' and k in TA[l]:o[k]=TA[l][k]
        elif k in T[l]:o[k]=T[l][k]
        elif k in auto:
          t,val=auto[k]
          if t=='C':o[k]=val
          else:
            name=loc.territories.get(val,src);o[k]=name.upper() if t=='TU' else name
      out[ns]=o
    json.dump(out,open(B+FILE.get(l,l)+'.json','w'),ensure_ascii=False,indent=2);open(B+FILE.get(l,l)+'.json','a').write('\n')
print('done',done,'/',len(todo));print(len(errs),'issues');print('\n'.join(errs[:60]))
