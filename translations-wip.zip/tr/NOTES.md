FR à corriger: 06ojvfz '1 lieu' -> '1 place'; 'MS Account' -> 'Compte MS' (0zuu1bs,0lymgbm,1q6td3o,0ge9v3i)
- account ns is separate from the site (flat). Use "@key#account" for account-only values.
- TODO end: add context keys to extra.en.json for gendered "Our": "Our >> Services" (es Nuestros, pt Nossos, it I nostri), check "Our | Seasons" (plain Our = feminine), "MS | Archives"; then review every multi-piece heading per language on rendered pages.
- zh Season = 季 ; "Season 27" = 27 季
- AUDIT: la Cookie Policy cite encore Squarespace comme hébergeur (1j942xc) alors que le site est sur Vercel -> à signaler/corriger EN+FR.
